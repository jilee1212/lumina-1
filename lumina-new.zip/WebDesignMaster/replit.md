# Lumina DeFi Platform

## Overview

Lumina is a comprehensive DeFi (Decentralized Finance) platform built as a modern web application featuring a React frontend with TypeScript, Express.js backend, and PostgreSQL database integration through Drizzle ORM. The project is designed to provide transparency, accessibility, and reliability in the DeFi ecosystem, centered around the $LMN token.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom theme system supporting light/dark modes
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Session Management**: Prepared for PostgreSQL session storage with connect-pg-simple
- **Development**: tsx for TypeScript execution in development

### Data Storage Solutions
- **Primary Database**: PostgreSQL (configured for production deployment)
- **Development Storage**: In-memory storage implementation for rapid development
- **ORM**: Drizzle ORM with type-safe schema definitions
- **Migrations**: Drizzle-kit for database schema management

## Key Components

### Authentication System
- User registration and login functionality (prepared but not fully implemented)
- PostgreSQL session storage for production environments
- Type-safe user schema with username/password authentication

### UI/UX Features
- **Theme System**: Light/dark mode toggle with system preference detection
- **Internationalization**: Multi-language support (English/Korean) with translation system
- **Responsive Design**: Mobile-first approach with comprehensive breakpoint coverage
- **Interactive Components**: Staking calculator, tokenomics charts, particle animations
- **Component Library**: Complete shadcn/ui implementation with 40+ components

### DeFi Platform Features
- **Tokenomics Visualization**: Interactive charts for token distribution
- **Staking Calculator**: Real-time APY calculations and reward estimations
- **Educational Content**: DeFi explainer with terminology definitions
- **Roadmap Timeline**: Interactive project milestone visualization

## Data Flow

1. **Client-Side Rendering**: React components fetch data through TanStack Query
2. **API Layer**: Express.js routes handle client requests (currently minimal)
3. **Data Access**: Storage interface abstracts database operations
4. **State Management**: React Query manages caching, synchronization, and updates
5. **Theme & Language**: Context providers handle global UI state

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI component primitives
- **drizzle-orm & drizzle-zod**: Database ORM and validation
- **wouter**: Lightweight routing library
- **chart.js**: Data visualization for tokenomics

### Development Tools
- **Vite**: Build tool with hot module replacement
- **@replit/vite-plugin-cartographer**: Replit-specific development enhancements
- **tailwindcss**: Utility-first CSS framework
- **tsx**: TypeScript execution for development

## Deployment Strategy

### Development Environment
- **Platform**: Replit with Node.js 20 runtime
- **Database**: PostgreSQL 16 module
- **Port Configuration**: Internal port 5000, external port 80
- **Hot Reload**: Vite development server with HMR

### Production Build
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Deployment**: Autoscale deployment target on Replit
- **Environment**: Production mode with optimized asset serving

### Configuration Management
- **Database**: Environment variable `DATABASE_URL` for PostgreSQL connection
- **Sessions**: PostgreSQL-backed session storage for production
- **Static Assets**: Express serves built frontend from `dist/public`

## Changelog

Changelog:
- June 16, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.