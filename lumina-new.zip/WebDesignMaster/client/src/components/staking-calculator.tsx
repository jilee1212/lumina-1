import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useLanguage } from '@/hooks/use-language';

export function StakingCalculator() {
  const [stakingAmount, setStakingAmount] = useState(10000);
  const [stakingPeriod, setStakingPeriod] = useState('50');
  const [estimatedProfit, setEstimatedProfit] = useState(0);
  const { t } = useLanguage();

  useEffect(() => {
    const amount = stakingAmount || 10000;
    const apyPercentage = parseFloat(stakingPeriod);
    const reward = amount * (apyPercentage / 100);
    setEstimatedProfit(reward);
  }, [stakingAmount, stakingPeriod]);

  return (
    <div className="glass-morphism p-8 rounded-2xl">
      <h4 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">
        {t('stakingCalculatorTitle')}
      </h4>
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <Label className="block text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">
            {t('stakingAmountLabel')}
          </Label>
          <Input
            type="number"
            value={stakingAmount}
            onChange={(e) => setStakingAmount(Number(e.target.value))}
            min="1"
            className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-300"
          />
          
          <Label className="block text-sm font-medium mb-3 mt-6 text-gray-700 dark:text-gray-300">
            {t('stakingPeriodLabel')}
          </Label>
          <Select value={stakingPeriod} onValueChange={setStakingPeriod}>
            <SelectTrigger className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-300">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="36">{t('period30')}</SelectItem>
              <SelectItem value="42">{t('period90')}</SelectItem>
              <SelectItem value="50">{t('period180')}</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center justify-center">
          <div className="text-center p-8 bg-gradient-to-br from-primary/10 to-blue-600/10 rounded-2xl border border-primary/20 w-full">
            <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">
              {t('estimatedAnnualProfit')}
            </div>
            <div className="text-4xl font-bold gradient-text">
              {estimatedProfit.toLocaleString()} $LMN
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
