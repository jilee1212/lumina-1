import { useEffect, useRef } from 'react';
import { useTheme } from '@/components/theme-provider';

export function TokenomicsChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { theme } = useTheme();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Import Chart.js dynamically
    import('chart.js/auto').then(({ default: Chart }) => {
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const isDark = theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
      
      const chart = new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: ['Staking Rewards', 'Ecosystem Growth', 'Team & Advisors', 'Initial Liquidity', 'Public/Private Sale', 'Airdrop/Events'],
          datasets: [{
            label: '$LMN Distribution',
            data: [40, 20, 15, 10, 10, 5],
            backgroundColor: [
              'rgba(99, 102, 241, 0.8)',
              'rgba(6, 182, 212, 0.8)',
              'rgba(16, 185, 129, 0.8)',
              'rgba(245, 158, 11, 0.8)',
              'rgba(139, 92, 246, 0.8)',
              'rgba(236, 72, 153, 0.8)'
            ],
            borderColor: [
              'rgba(99, 102, 241, 1)',
              'rgba(6, 182, 212, 1)',
              'rgba(16, 185, 129, 1)',
              'rgba(245, 158, 11, 1)',
              'rgba(139, 92, 246, 1)',
              'rgba(236, 72, 153, 1)'
            ],
            borderWidth: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                color: isDark ? '#e2e8f0' : '#374151',
                padding: 20,
                usePointStyle: true,
                font: {
                  size: 12
                }
              }
            },
            title: {
              display: true,
              text: '$LMN Token Distribution (Total 1 Billion)',
              font: {
                size: 16,
                weight: 'bold'
              },
              color: isDark ? '#e2e8f0' : '#374151',
              padding: 20
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  let label = context.label || '';
                  if (label) {
                    label += ': ';
                  }
                  if (context.parsed !== null) {
                    label += context.parsed + '%';
                  }
                  return label;
                }
              }
            }
          }
        }
      });

      return () => {
        chart.destroy();
      };
    });
  }, [theme]);

  return (
    <div className="chart-container p-8 rounded-3xl">
      <h3 className="text-2xl font-bold mb-6 text-center text-gray-900 dark:text-white">
        Token Distribution
      </h3>
      <div className="relative h-80">
        <canvas ref={canvasRef} />
      </div>
    </div>
  );
}
