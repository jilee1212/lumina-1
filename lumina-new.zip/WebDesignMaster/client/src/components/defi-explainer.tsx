import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Loader2 } from 'lucide-react';
import { useLanguage } from '@/hooks/use-language';

export function DefiExplainer() {
  const [term, setTerm] = useState('');
  const [explanation, setExplanation] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(false);
  const { t, currentLanguage } = useLanguage();

  const mockExplanations: Record<string, string> = {
    "liquidity pool": "A liquidity pool is a collection of funds locked in a smart contract. Users called liquidity providers (LPs) add an equal value of two tokens to create a market. These pools enable decentralized trading and earn fees for providers.",
    "yield farming": "Yield farming is the practice of staking or lending crypto assets to generate high returns or rewards in the form of additional cryptocurrency. It's like earning interest on your crypto holdings.",
    "defi": "DeFi (Decentralized Finance) refers to financial services built on blockchain technology that operate without traditional intermediaries like banks. It includes lending, borrowing, trading, and earning interest on cryptocurrency.",
    "apy": "APY (Annual Percentage Yield) represents the real rate of return earned on an investment, taking into account the effect of compounding interest over a year.",
    "dex": "A DEX (Decentralized Exchange) is a peer-to-peer marketplace where cryptocurrency traders make transactions directly without handing over management of their funds to an intermediary or custodian.",
    "유동성 풀": "유동성 풀은 스마트 컨트랙트에 잠긴 자금의 모음입니다. 유동성 공급자(LP)라고 불리는 사용자들이 두 토큰의 동일한 가치를 추가하여 시장을 만듭니다. 이러한 풀은 탈중앙화 거래를 가능하게 하고 공급자에게 수수료를 제공합니다.",
    "이자 농사": "이자 농사는 추가 암호화폐 형태의 높은 수익이나 보상을 창출하기 위해 암호화폐 자산을 스테이킹하거나 대여하는 관행입니다. 암호화폐 보유에 대한 이자를 얻는 것과 같습니다."
  };

  const handleExplain = async () => {
    if (!term.trim()) {
      setExplanation(t('defiExplainerPrompt'));
      setError(false);
      return;
    }

    setExplanation('');
    setError(false);
    setIsLoading(true);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const explanation = mockExplanations[term.toLowerCase()] || 
        `${term} is a concept in DeFi that involves various blockchain-based financial mechanisms. For detailed information, please consult official DeFi documentation or educational resources.`;
      
      setExplanation(explanation);
    } catch (error) {
      console.error("Error in DeFi explainer:", error);
      setExplanation(t('defiNetworkError'));
      setError(true);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="glass-morphism p-8 rounded-3xl">
      <h3 className="text-3xl font-bold mb-4 text-center gradient-text">
        {t('defiExplainerTitle')}
      </h3>
      <p className="text-center text-gray-600 dark:text-gray-400 mb-8">
        {t('defiExplainerSubtitle')}
      </p>
      <div className="max-w-2xl mx-auto">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <Input
            type="text"
            value={term}
            onChange={(e) => setTerm(e.target.value)}
            placeholder="Enter DeFi term (e.g., 'liquidity pool', 'yield farming')"
            className="flex-1 px-6 py-4 rounded-2xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-300"
            onKeyPress={(e) => e.key === 'Enter' && handleExplain()}
          />
          <Button 
            onClick={handleExplain}
            disabled={isLoading}
            className="btn-primary px-8 py-4 rounded-2xl text-white font-semibold hover:scale-105 transition-all duration-300"
          >
            {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            {t('explainButton')}
          </Button>
        </div>
        <div className="p-6 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 rounded-2xl text-gray-800 dark:text-gray-200 min-h-[120px] whitespace-pre-wrap">
          {explanation || t('defiExplainerPrompt')}
        </div>
        {error && (
          <div className="mt-4 p-4 bg-red-100 dark:bg-red-900/30 border border-red-200 dark:border-red-700 text-red-800 dark:text-red-200 rounded-xl">
            {t('defiExplanationFailed')}
          </div>
        )}
      </div>
    </div>
  );
}
