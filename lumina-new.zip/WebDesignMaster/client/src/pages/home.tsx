import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Moon, Sun, Menu, X, Zap, Shield, Gauge, DollarSign, Vote, TrendingUp, ArrowLeftRight, Coins, Heart, CheckCircle, Lock, Key, BarChart3, Download } from 'lucide-react';
import { useTheme } from '@/components/theme-provider';
import { useLanguage } from '@/hooks/use-language';
import { ParticleAnimation } from '@/components/particle-animation';
import { StakingCalculator } from '@/components/staking-calculator';
import { TokenomicsChart } from '@/components/tokenomics-chart';
import { DefiExplainer } from '@/components/defi-explainer';

export default function Home() {
  const { theme, setTheme } = useTheme();
  const { currentLanguage, toggleLanguage, t } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('dex');
  const [expandedTimeline, setExpandedTimeline] = useState<number | null>(null);

  const isDark = theme === 'dark';

  const handleSmoothScroll = (elementId: string) => {
    const element = document.getElementById(elementId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  const timelineItems = [
    {
      id: 1,
      quarter: t('roadmapQ32025Title'),
      description: t('roadmapQ32025Text'),
      status: 'current',
      details: [
        'Smart contract architecture design',
        'Community Discord & Telegram launch', 
        'Initial marketing campaign',
        'Strategic partnerships exploration'
      ]
    },
    {
      id: 2,
      quarter: t('roadmapQ42025Title'),
      description: t('roadmapQ42025Text'),
      status: 'upcoming',
      details: [
        'Token generation event (TGE)',
        'DEX beta testing with community',
        'Initial liquidity mining programs',
        'CEX listing preparations'
      ]
    },
    {
      id: 3,
      quarter: t('roadmapQ12026Title'),
      description: t('roadmapQ12026Text'),
      status: 'future',
      details: [
        'Staking rewards program launch',
        'Advanced trading features',
        'Mobile app development',
        'Community governance implementation'
      ]
    },
    {
      id: 4,
      quarter: t('roadmap2026OnwardTitle'),
      description: t('roadmap2026OnwardText'),
      status: 'future',
      details: [
        'Multi-chain deployment (Ethereum, BSC, Polygon)',
        'Real World Asset (RWA) tokenization',
        'Institutional partnerships',
        'Global regulatory compliance'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 nav-blur">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <a href="#" className="text-3xl font-bold gradient-text hover:scale-105 transition-transform duration-300">
              Lumina
            </a>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <button onClick={() => handleSmoothScroll('vision')} className="nav-link font-medium hover:text-primary transition-colors duration-300">
                {t('navVision')}
              </button>
              <button onClick={() => handleSmoothScroll('tokenomics')} className="nav-link font-medium hover:text-primary transition-colors duration-300">
                {t('navTokenomics')}
              </button>
              <button onClick={() => handleSmoothScroll('ecosystem')} className="nav-link font-medium hover:text-primary transition-colors duration-300">
                {t('navEcosystem')}
              </button>
              <button onClick={() => handleSmoothScroll('roadmap')} className="nav-link font-medium hover:text-primary transition-colors duration-300">
                {t('navRoadmap')}
              </button>
              <button onClick={() => handleSmoothScroll('security')} className="nav-link font-medium hover:text-primary transition-colors duration-300">
                {t('navSecurity')}
              </button>
            </nav>

            {/* Desktop Controls */}
            <div className="hidden md:flex items-center space-x-4">
              <Button
                onClick={toggleLanguage}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-primary to-blue-600 text-white hover:scale-105 transition-all duration-300 font-medium"
              >
                {currentLanguage.toUpperCase()}
              </Button>
              <Button
                onClick={() => setTheme(isDark ? 'light' : 'dark')}
                size="icon"
                className="p-3 rounded-xl glass-morphism hover:scale-105 transition-all duration-300"
              >
                {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <Button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              size="icon"
              className="md:hidden p-3 rounded-xl glass-morphism"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden glass-morphism border-t border-white/10">
            <div className="container mx-auto px-4 py-6">
              <div className="flex flex-col space-y-4">
                <button onClick={() => handleSmoothScroll('vision')} className="nav-link font-medium text-left">
                  {t('navVision')}
                </button>
                <button onClick={() => handleSmoothScroll('tokenomics')} className="nav-link font-medium text-left">
                  {t('navTokenomics')}
                </button>
                <button onClick={() => handleSmoothScroll('ecosystem')} className="nav-link font-medium text-left">
                  {t('navEcosystem')}
                </button>
                <button onClick={() => handleSmoothScroll('roadmap')} className="nav-link font-medium text-left">
                  {t('navRoadmap')}
                </button>
                <button onClick={() => handleSmoothScroll('security')} className="nav-link font-medium text-left">
                  {t('navSecurity')}
                </button>
                <div className="flex space-x-4 pt-4">
                  <Button
                    onClick={toggleLanguage}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-primary to-blue-600 text-white font-medium"
                  >
                    {currentLanguage.toUpperCase()}
                  </Button>
                  <Button
                    onClick={() => setTheme(isDark ? 'light' : 'dark')}
                    size="icon"
                    className="p-3 rounded-xl glass-morphism"
                  >
                    {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="pt-20">
        {/* Hero Section */}
        <section id="hero" className="relative min-h-screen flex items-center justify-center hero-gradient overflow-hidden">
          <ParticleAnimation />
          
          {/* Enhanced background elements */}
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-primary to-cyan-500 rounded-full blur-3xl"></div>
            <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gradient-to-r from-blue-600 to-emerald-500 rounded-full blur-3xl"></div>
          </div>
          
          <div className="container mx-auto px-4 py-16 text-center relative z-10">
            <div className="animate-fade-in">
              <h1 className="text-6xl md:text-7xl font-bold mb-8 bg-gradient-to-r from-foreground via-foreground to-foreground bg-clip-text text-transparent leading-tight">
                {t('heroTitle')}
              </h1>
              <p className="text-xl md:text-2xl mb-12 text-muted-foreground max-w-4xl mx-auto leading-relaxed animate-slide-up">
                {t('heroSubtitle')}
              </p>
              <div className="flex flex-col md:flex-row gap-6 justify-center items-center mt-12 animate-slide-up">
                <Button 
                  onClick={() => handleSmoothScroll('ecosystem')}
                  className="btn-primary px-10 py-4 rounded-2xl text-white font-semibold text-lg hover:scale-105 transition-all duration-300"
                >
                  {t('exploreEcosystemBtn')}
                </Button>
                <div className="flex flex-col md:flex-row gap-4">
                  <Button className="btn-secondary px-8 py-4 rounded-2xl text-white font-semibold hover:scale-105 transition-all duration-300">
                    <Download className="w-4 h-4 mr-2" />
                    {t('downloadWhitepaperBtn')}
                    <span className="text-sm ml-2 opacity-80">(EN)</span>
                  </Button>
                  <Button className="btn-secondary px-8 py-4 rounded-2xl text-white font-semibold hover:scale-105 transition-all duration-300">
                    <Download className="w-4 h-4 mr-2" />
                    {t('downloadWhitepaperBtn')}
                    <span className="text-sm ml-2 opacity-80">(KR)</span>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Vision Section */}
        <section id="vision" className="section-padding bg-card relative">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold mb-6 gradient-text">{t('whyLuminaTitle')}</h2>
              <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
                {t('whyLuminaSubtitle')}
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <Card className="glass-morphism hover-lift border-0">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-primary to-blue-600 rounded-2xl mb-6 flex items-center justify-center">
                    <Zap className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">{t('visionArbitrageTitle')}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {t('visionArbitrageText')}
                  </p>
                </CardContent>
              </Card>
              
              <Card className="glass-morphism hover-lift border-0">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-cyan-500 to-emerald-500 rounded-2xl mb-6 flex items-center justify-center">
                    <Shield className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">{t('visionSecurityTitle')}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {t('visionSecurityText')}
                  </p>
                </CardContent>
              </Card>
              
              <Card className="glass-morphism hover-lift border-0">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-2xl mb-6 flex items-center justify-center">
                    <Gauge className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">{t('visionGasEfficiencyTitle')}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {t('visionGasEfficiencyText')}
                  </p>
                </CardContent>
              </Card>
              
              <Card className="glass-morphism hover-lift border-0">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl mb-6 flex items-center justify-center">
                    <DollarSign className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">{t('visionTokenEconomyTitle')}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {t('visionTokenEconomyText')}
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Tokenomics Section */}
        <section id="tokenomics" className="section-padding bg-muted relative overflow-hidden">
          <div className="absolute inset-0 opacity-5">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-cyan-500 rounded-full blur-3xl"></div>
          </div>
          
          <div className="container mx-auto px-4 relative z-10">
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold mb-6 gradient-text">{t('tokenomicsTitle')}</h2>
              <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
                {t('tokenomicsSubtitle')}
              </p>
            </div>
            
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div className="space-y-8">
                <div>
                  <h3 className="text-3xl font-bold mb-8">{t('tokenKeyRolesTitle')}</h3>
                  <div className="space-y-6">
                    <Card className="glass-morphism hover-lift border-0">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-r from-primary to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                            <Vote className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h4 className="text-xl font-bold mb-2">{t('roleGovernanceTitle')}</h4>
                            <p className="text-muted-foreground">{t('roleGovernanceText')}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="glass-morphism hover-lift border-0">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-emerald-500 rounded-xl flex items-center justify-center flex-shrink-0">
                            <TrendingUp className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h4 className="text-xl font-bold mb-2">{t('roleStakingRewardsTitle')}</h4>
                            <p className="text-muted-foreground">{t('roleStakingRewardsText')}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="glass-morphism hover-lift border-0">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center flex-shrink-0">
                            <Gauge className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h4 className="text-xl font-bold mb-2">{t('roleFeeDiscountTitle')}</h4>
                            <p className="text-muted-foreground">{t('roleFeeDiscountText')}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="glass-morphism hover-lift border-0">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center flex-shrink-0">
                            <Coins className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h4 className="text-xl font-bold mb-2">{t('roleLiquidityIncentivesTitle')}</h4>
                            <p className="text-muted-foreground">{t('roleLiquidityIncentivesText')}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
              
              <div className="space-y-8">
                <TokenomicsChart />
                
                <Card className="glass-morphism border-0">
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-bold mb-6">{t('valueMechanismTitle')}</h3>
                    <p className="text-muted-foreground mb-8 leading-relaxed">
                      {t('valueMechanismText')}
                    </p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-4 bg-gradient-to-br from-primary/10 to-blue-600/10 rounded-2xl border border-primary/20">
                        <div className="text-3xl font-bold gradient-text mb-2">1</div>
                        <div className="text-sm text-muted-foreground">{t('step1DEXProfit')}</div>
                      </div>
                      <div className="text-center p-4 bg-gradient-to-br from-cyan-500/10 to-emerald-500/10 rounded-2xl border border-cyan-500/20">
                        <div className="text-3xl font-bold gradient-text mb-2">2</div>
                        <div className="text-sm text-muted-foreground">{t('step2Buyback')}</div>
                      </div>
                      <div className="text-center p-4 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 rounded-2xl border border-emerald-500/20">
                        <div className="text-3xl font-bold gradient-text mb-2">3</div>
                        <div className="text-sm text-muted-foreground">{t('step3Burn')}</div>
                      </div>
                      <div className="text-center p-4 bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-2xl border border-purple-500/20">
                        <div className="text-3xl font-bold gradient-text mb-2">4</div>
                        <div className="text-sm text-muted-foreground">{t('step4ValueIncrease')}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Ecosystem Section */}
        <section id="ecosystem" className="section-padding bg-card">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold mb-6 gradient-text">{t('ecosystemTitle')}</h2>
              <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
                {t('ecosystemSubtitle')}
              </p>
            </div>
            
            <Card className="glass-morphism border-0 overflow-hidden">
              <CardContent className="p-0">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <div className="flex flex-col md:flex-row">
                    <div className="md:w-1/3 p-2">
                      <TabsList className="flex flex-col h-auto space-y-2 bg-transparent">
                        <TabsTrigger 
                          value="dex" 
                          className="w-full justify-start px-8 py-4 rounded-2xl text-left font-semibold transition-all duration-300 data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-blue-600 data-[state=active]:text-white"
                        >
                          {t('dexTabBtn')}
                        </TabsTrigger>
                        <TabsTrigger 
                          value="staking" 
                          className="w-full justify-start px-8 py-4 rounded-2xl text-left font-semibold transition-all duration-300 data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-blue-600 data-[state=active]:text-white"
                        >
                          {t('stakingTabBtn')}
                        </TabsTrigger>
                      </TabsList>
                    </div>
                    <div className="md:w-2/3 p-8">
                      <TabsContent value="dex" className="mt-0">
                        <h3 className="text-3xl font-bold mb-6">{t('dexContentTitle')}</h3>
                        <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
                          {t('dexContentText')}
                        </p>
                        <div className="grid md:grid-cols-3 gap-6">
                          <div className="text-center p-6 bg-gradient-to-br from-primary/5 to-blue-600/5 rounded-2xl border border-primary/10">
                            <div className="w-12 h-12 bg-gradient-to-r from-primary to-blue-600 rounded-xl mx-auto mb-4 flex items-center justify-center">
                              <ArrowLeftRight className="w-6 h-6 text-white" />
                            </div>
                            <h4 className="font-bold mb-2">{t('dexFeatureSwap')}</h4>
                          </div>
                          <div className="text-center p-6 bg-gradient-to-br from-cyan-500/5 to-emerald-500/5 rounded-2xl border border-cyan-500/10">
                            <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-emerald-500 rounded-xl mx-auto mb-4 flex items-center justify-center">
                              <Coins className="w-6 h-6 text-white" />
                            </div>
                            <h4 className="font-bold mb-2">{t('dexFeatureFarming')}</h4>
                          </div>
                          <div className="text-center p-6 bg-gradient-to-br from-emerald-500/5 to-teal-500/5 rounded-2xl border border-emerald-500/10">
                            <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl mx-auto mb-4 flex items-center justify-center">
                              <Heart className="w-6 h-6 text-white" />
                            </div>
                            <h4 className="font-bold mb-2">{t('dexFeatureUX')}</h4>
                          </div>
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="staking" className="mt-0">
                        <h3 className="text-3xl font-bold mb-6">{t('stakingContentTitle')}</h3>
                        <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
                          {t('stakingContentText')}
                        </p>
                        <StakingCalculator />
                      </TabsContent>
                    </div>
                  </div>
                </Tabs>
              </CardContent>
            </Card>
            
            {/* DeFi Explainer Section */}
            <div className="mt-16">
              <DefiExplainer />
            </div>
          </div>
        </section>

        {/* Roadmap Section */}
        <section id="roadmap" className="section-padding bg-muted relative overflow-hidden">
          <div className="absolute inset-0 opacity-5">
            <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-emerald-500 rounded-full blur-3xl"></div>
            <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-primary rounded-full blur-3xl"></div>
          </div>
          
          <div className="container mx-auto px-4 relative z-10">
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold mb-6 gradient-text">{t('roadmapTitle')}</h2>
              <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
                {t('roadmapSubtitle')}
              </p>
            </div>
            
            <div className="max-w-4xl mx-auto">
              <div className="relative">
                {/* Timeline line */}
                <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary via-cyan-500 to-emerald-500"></div>
                
                <div className="space-y-12">
                  {timelineItems.map((item, index) => (
                    <Card 
                      key={item.id}
                      className="relative pl-20 cursor-pointer hover-lift glass-morphism border-0"
                      onClick={() => setExpandedTimeline(expandedTimeline === item.id ? null : item.id)}
                    >
                      <div className="absolute left-6 top-8 w-4 h-4 bg-gradient-to-r from-primary to-blue-600 rounded-full border-4 border-background"></div>
                      <CardContent className="p-8">
                        <div className="flex justify-between items-start mb-4">
                          <h3 className="text-2xl font-bold">{item.quarter}</h3>
                          {item.status === 'current' && (
                            <Badge className="bg-primary/10 text-primary hover:bg-primary/20">
                              Current
                            </Badge>
                          )}
                          {item.status === 'upcoming' && (
                            <Badge className="bg-cyan-500/10 text-cyan-500 hover:bg-cyan-500/20">
                              Upcoming
                            </Badge>
                          )}
                        </div>
                        <p className="text-muted-foreground leading-relaxed">
                          {item.description}
                        </p>
                        {expandedTimeline === item.id && (
                          <div className="mt-6 pt-6 border-t border-border">
                            <ul className="space-y-2 text-sm text-muted-foreground">
                              {item.details.map((detail, detailIndex) => (
                                <li key={detailIndex}>• {detail}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Security Section */}
        <section id="security" className="section-padding bg-card">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold mb-6 gradient-text">{t('securityTitle')}</h2>
              <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
                {t('securitySubtitle')}
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <Card className="glass-morphism hover-lift border-0 text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-primary to-blue-600 rounded-2xl mx-auto mb-6 flex items-center justify-center">
                    <CheckCircle className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-4">{t('securityAuditTitle')}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {t('securityAuditText')}
                  </p>
                </CardContent>
              </Card>
              
              <Card className="glass-morphism hover-lift border-0 text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-cyan-500 to-emerald-500 rounded-2xl mx-auto mb-6 flex items-center justify-center">
                    <Lock className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-4">{t('securityBugBountyTitle')}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {t('securityBugBountyText')}
                  </p>
                </CardContent>
              </Card>
              
              <Card className="glass-morphism hover-lift border-0 text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-2xl mx-auto mb-6 flex items-center justify-center">
                    <Key className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-4">{t('securityMultiSigTitle')}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {t('securityMultiSigText')}
                  </p>
                </CardContent>
              </Card>
              
              <Card className="glass-morphism hover-lift border-0 text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl mx-auto mb-6 flex items-center justify-center">
                    <BarChart3 className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-4">{t('securityRiskMgmtTitle')}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {t('securityRiskMgmtText')}
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-muted border-t">
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <div className="mb-8">
              <a href="#" className="text-4xl font-bold gradient-text">
                {t('footerLumina')}
              </a>
              <p className="text-muted-foreground mt-4 text-lg">
                {t('footerMission')}
              </p>
            </div>
            <div className="pt-8 border-t border-border">
              <p className="text-muted-foreground">
                {t('footerCopyright')}
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
