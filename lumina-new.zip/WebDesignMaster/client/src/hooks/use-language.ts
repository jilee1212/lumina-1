import { useState, useCallback } from 'react';
import { translations, Language, TranslationKey } from '@/lib/translations';

export function useLanguage() {
  const [currentLanguage, setCurrentLanguage] = useState<Language>('en');

  const t = useCallback((key: TranslationKey): string => {
    return translations[currentLanguage][key] || key;
  }, [currentLanguage]);

  const toggleLanguage = useCallback(() => {
    setCurrentLanguage(prev => prev === 'en' ? 'ko' : 'en');
  }, []);

  return {
    currentLanguage,
    setLanguage: setCurrentLanguage,
    toggleLanguage,
    t
  };
}
